/* Tells the compiler not to add padding for these structs. This may
   be useful when reading/writing to binary files.
   http://stackoverflow.com/questions/3318410/pragma-pack-effect
*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#pragma pack(1)

typedef struct {
    unsigned char  fileMarker1; /* 'B' */
    unsigned char  fileMarker2; /* 'M' */
    unsigned int   bfSize; /* File's size */
    unsigned short unused1; /* Aplication specific */
    unsigned short unused2; /* Aplication specific */
    unsigned int   imageDataOffset; /* Offset to the start of image data */
} bmp_fileheader;
typedef struct {
    unsigned int   biSize; /* Size of the info header - 40 bytes */
    signed int     width; /* Width of the image */
    signed int     height; /* Height of the image */
    unsigned short planes;
    unsigned short bitPix; /* Number of bits per pixel = 3 * 8 (for each channel R, G, B we need 8 bits */
    unsigned int   biCompression; /* Type of compression */
    unsigned int   biSizeImage; /* Size of the image data */
    int            biXPelsPerMeter;
    int            biYPelsPerMeter;
    unsigned int   biClrUsed;
    unsigned int   biClrImportant;
} bmp_infoheader;

typedef struct {
    // struct pentru a citi o matrice de biti.
    unsigned char Blue , Green , Red;
} bmp_bitmap;

#pragma pack()

bmp_bitmap **buildmatrix(FILE *fin, bmp_infoheader bmpheader) {
    int i = 0;
    /*Structul in care citesc matricea si am grija la pdding folosind formula
    4 - ((bmpheader.width * 3) % 4) si asigurandu-ma ca widht-ul nu este multiplu de 4. La final
    functia returneaza un pointer catre matrice*/
    bmp_bitmap **p = malloc(bmpheader.height * sizeof(void *));
    for (i = 0; i < bmpheader.height; i++)
        p[i] = (bmp_bitmap *)malloc(bmpheader.width * sizeof(bmp_bitmap));
    for (i = 0; i < bmpheader.height; i++) {
        fread(p[i], sizeof(bmp_bitmap), bmpheader.width, fin);
        if (bmpheader.width % 4 != 0)
            fseek(fin, 4 - ((bmpheader.width * 3) % 4), SEEK_CUR);
    }
    return p;
}
int min1(int a, int b) {
    if (a < b)
        return a;
    return b;
}
int max1(int a, int b) {
    if (a > b)
        return a;
    else
        return b;
}
void line_width(int x, bmp_bitmap **mat, int i, int j, bmp_bitmap rgb, bmp_infoheader *infoheader) {
    /*In aceasta functie calculez dimensile patratului, ce reprezinta marimea "pensula"
    Dupa asta parcurg dimensiunile acelui patrat, si il inlocuiesc fiecare pixel, cu o culoare
    primita ca input*/
    int stangasus = 0, dreaptasus = 0, dreaptajos = 0, stangajos = 0;
    mat[i][j] = rgb;
    stangasus = i - x / 2;
    stangajos = j - x / 2;
    dreaptajos = i + x / 2;
    dreaptasus = j + x / 2;
    if (stangasus < 0)
        stangasus = 0;
    if (stangajos < 0)
        stangajos = 0;
    if (dreaptasus >= infoheader->width)
        dreaptasus = infoheader->width - 1;
    if (dreaptajos >= infoheader->height)
        dreaptajos = infoheader->height - 1;
    for (i = stangasus; i <= dreaptajos; i++)
        for (j = stangajos; j <= dreaptasus; j++)
            mat[i][j] = rgb;
}
int compara(bmp_bitmap b, bmp_bitmap c) {
    // compara pixeli
    if (b.Blue == c.Blue && b.Green == c.Green && b.Red == c.Red)
        return 1;
    return 0;
}
void lucreazax(int x1, int y1, int x2, int y2, bmp_bitmap **mat, int size, bmp_infoheader *info, bmp_bitmap rgb) {
    int i = 0, y = 0;
    // uneste punctele din intervalul functie de coordonate  x , f(x) din for.
    for (i = min1(x1, x2); i <= max1(x2, x1); i++) {
        y = ((i - x1) * (y2 - y1) + y1 * (x2 - x1)) / (x2 - x1);
        if (y >= 0 && y < info->width && i >= 0 && i < info->height)
        line_width(size, mat, i, y, rgb, info);
    }
}
void lucreazay(int x1, int y1, int x2, int y2, bmp_bitmap **mat, int size, bmp_infoheader *info, bmp_bitmap rgb) {
    int i = 0, x = 0;
    // la fel ca mai sus dar pentru y.
    for (i = min1(y1, y2); i <= max1(y2, y1); i++) {
        x = ((i - y1) * (x2 - x1) + x1 * (y2 - y1)) / (y2 - y1);
        if ( x >= 0 && x < info->height && i >= 0 && i < info->width)
        line_width(size, mat, x, i, rgb, info);
    }
}
void drawline(int x1, int y1, int x2, int y2, bmp_bitmap **mat, int size, bmp_infoheader *infoheader, bmp_bitmap rgb) {
    /*Aici verific care interval este mai mare din formula matematica explicata in cerinta
    task-ului*/
    if ((max1(x1, x2) - min1(x1, x2)) > (max1(y1, y2) - min1(y1, y2)))
        lucreazax(x1, y1, x2, y2, mat, size, infoheader, rgb);
    else
        lucreazay(x1, y1, x2, y2, mat, size, infoheader, rgb);
}
void drawrectangle(int x1, int y1, int w, int h, bmp_bitmap **mat, int size, bmp_infoheader *ih, bmp_bitmap rgb) {
    // Calculez cele 3 puncte ramase pentru a le putea unii ca sa obtin un dreptunhgi
    int i1 = 0, j1 = 0, i2 = 0, j2 = 0, i3 = 0, j3 = 0;
    i1 = x1 + h;
    j1 = y1;
    i2 = x1;
    j2 = y1 + w;
    i3 = i1;
    j3 = j2;
    drawline(x1, y1, i1, j1, mat, size, ih, rgb);
    drawline(x1, y1, i2, j2, mat, size, ih, rgb);
    drawline(i3, j3, i1, j1, mat, size, ih, rgb);
    drawline(i2, j2, i3, j3, mat, size, ih, rgb);
}
void fillrec(int i, int j, bmp_bitmap **mat, bmp_infoheader *infoheader, bmp_bitmap rgb, bmp_bitmap rgb2) {
    mat[i][j] = rgb;
    /*Functia mea recursiva de fill verifica daca vecinii sunt valizi(adica daca au 
    o culoare ce trebuie schimbata sau daca nu au depasit limitele matricei
    in cazul in care este valid functia se autoapeleaza pe acea pozitie si ii schimba
    valoarea pixelului*/
    if (i - 1 >= 0 && compara(rgb2, mat[i-1][j]) == 1)
        fillrec(i - 1 , j , mat , infoheader , rgb , rgb2);
    if (j - 1 >= 0 && compara(rgb2, mat[i][j-1]) == 1)
        fillrec(i  , j - 1 , mat , infoheader , rgb , rgb2);
    if (i + 1 < infoheader->height && compara(rgb2, mat[i+1][j]) == 1)
        fillrec(i + 1 , j , mat , infoheader , rgb , rgb2);
    if (j+1 < infoheader->width && compara(rgb2, mat[i][j+1]) == 1)
        fillrec(i , j + 1 , mat , infoheader , rgb , rgb2);
}
void fill(int i, int j, bmp_bitmap **mat, bmp_infoheader *infoheader, bmp_bitmap rgb) {
    /*Aceasta functie apeleaza functia recursiva de fill*/
    bmp_bitmap rgb2;
    rgb2  = mat[i][j];
    mat[i][j] = rgb;
    if (i >= 0 && i < infoheader->height && j >= 0 && j < infoheader->width)
    fillrec(i, j, mat, infoheader, rgb, rgb2);
}
