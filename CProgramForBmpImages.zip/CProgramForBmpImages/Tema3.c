#include "bmp_header.h"

int main() {
    int i = 0 , j = 0, poz2i = 0, poz2j = 0;
    bmp_bitmap **mat = NULL, **mat2 = NULL, rgb;
    int x = 0 , y = 0;
    int size = 0;
    const int numar = 50, numar1 = 100;
    char *adresain = malloc(numar1 * sizeof(char));
    bmp_fileheader *bmpheader = malloc(sizeof(bmp_fileheader));
    bmp_infoheader *infoheader = malloc(sizeof(bmp_infoheader));
    bmp_fileheader *bmpheader2 = malloc(sizeof(bmp_fileheader));
    bmp_infoheader *infoheader2 = malloc(sizeof(bmp_infoheader));
    char *optiune = calloc(numar , sizeof(char));
    while (scanf("%s", optiune) != EOF) {
        if (strcmp("edit", optiune) == 0) {
            /*In aceasta functie citim din fisierul sursa imaginea utilizand struct-urile din header
            si folosind fseek pemtru padding, iar la final inchidem fisierul din care am citit.*/
            scanf("%s", adresain);
            FILE *fin = fopen(adresain, "rb");
            if (fin == NULL) {
                fclose(fin);
            }
            fread(bmpheader, sizeof(bmp_fileheader), 1, fin);
            fread(infoheader, sizeof(bmp_infoheader), 1, fin);
            fseek(fin, bmpheader->imageDataOffset, SEEK_SET);
            mat = buildmatrix(fin, *infoheader);
            fclose(fin);
        }
        if (strcmp("save", optiune) == 0) {
            /*Programul scrie in fisierul
            de la adresa in imaginea modificata
            Avand grija la padding. Padding-ul de la scriere. Intre header si matricea de pixeli
            se afla  un anumit numar de pixeli, valoarea imageDataoffSet cu valoarea 0 ce trebuisc adaugati */
            scanf("%s", adresain);
            char padding = 0;
            padding = 0;
            int nr = 0;
            nr = 4 - ((infoheader->width * 3) % 4);
            FILE *fout = fopen(adresain, "wb");
             if (fout == NULL) {
                fclose(fout);
            }
            fwrite(bmpheader, sizeof(bmp_fileheader), 1, fout);
            fwrite(infoheader, sizeof(bmp_infoheader), 1, fout);
            for ( int p = (int)ftell(fout) ; p < bmpheader->imageDataOffset ; p++)
                 fwrite(&padding, sizeof(char), 1, fout);
            for (i = 0; i < infoheader->height; i++) {
                fwrite(mat[i], sizeof(bmp_bitmap), infoheader->width, fout);
                if (infoheader->width % 4 != 0) {
                    for (int p = 0; p < nr; p++)
                        fwrite(&padding, sizeof(char), 1, fout);
                }
            }
            fclose(fout);
        }
        if (strcmp("quit", optiune) == 0) {
            /*Programul in optiunea de quit 
            elibereaza toata memoria ramasa pe heap*/
            for (i = 0; i < infoheader->height; i++)
                free(mat[i]);
            free(mat);
            free(optiune);
            free(bmpheader);
            free(infoheader);
            free(bmpheader2);
            free(infoheader2);
            free(adresain);
            break;
        }
        if (strcmp("insert", optiune) == 0) {
            /*In aceasta functie, programul citeste a 2 imagine
            ai carei pixeli trepusi pusi peste cei prima imagine.
            Cu 2 while-uri verific sa nu depasesc dimensiunile uneia din cele 2 matrici.*/
            scanf("%s", adresain);
            scanf("%d%d", &y, &x);
            FILE *fin = fopen(adresain, "rb");
            if (fin == NULL) {
                fclose(fin);
            }
            fread(bmpheader2, sizeof(bmp_fileheader), 1, fin);
            fread(infoheader2, sizeof(bmp_infoheader), 1, fin);
            fseek(fin, bmpheader2->imageDataOffset, SEEK_SET);
            mat2 = buildmatrix(fin, *infoheader2);
            fclose(fin);
            i =(int) x;
            j =(int) y;
            poz2i = poz2j = 0;
            while (i < infoheader->height && poz2i < infoheader2->height) {
                while (j < infoheader->width && poz2j < infoheader2->width) {
                    mat[i][j] = mat2[poz2i][poz2j];
                    j++;
                    poz2j++;
                }
                j = y;
                poz2j = 0;
                poz2i++;
                i++;
            }
            for (i = 0; i < infoheader2->height; i++)
                free(mat2[i]);
            free(mat2);
        }
        if (strcmp("set", optiune) == 0) {
            scanf("%s", optiune);
            if (strcmp("draw_color", optiune) == 0) {
                int b = 0, g = 0, r = 0;
                scanf("%d%d%d", &r, &g, &b);
                rgb.Blue = b;
                rgb.Green = g;
                rgb.Red = r;
            }
            if (strcmp("line_width", optiune) == 0) {
                // citesc dimensiunea "pensulei"
                scanf("%d", &size);
            }
        }
        if (strcmp("draw", optiune) == 0) {
            scanf("%s", optiune);
            int x1 = 0, x2 = 0, y1 = 0, y2 = 0, x3 = 0, y3 = 0, width = 0, height = 0;
            if (strcmp("line", optiune) == 0) {
                scanf("%d%d%d%d", &y1, &x1, &y2, &x2);
                drawline(x1, y1, x2, y2, mat, size, infoheader, rgb);
            }
            if (strcmp("triangle", optiune) == 0) {
                scanf("%d%d%d%d%d%d", &y1, &x1, &y2, &x2, &y3, &x3);
                drawline(x1, y1, x2, y2, mat, size, infoheader, rgb);
                drawline(x1, y1, x3, y3, mat, size, infoheader, rgb);
                drawline(x3, y3, x2, y2, mat, size, infoheader, rgb);
            }
           if (strcmp("rectangle", optiune) == 0) {
                scanf("%d%d%d%d", &y1, &x1, &width, &height);
                drawrectangle(x1, y1, width, height, mat, size, infoheader, rgb);
            }
        }
        if (strcmp("fill", optiune) == 0) {
            scanf("%d%d", &y, &x);
            fill(x, y, mat, infoheader, rgb);
        }
    }
return 0;
}
